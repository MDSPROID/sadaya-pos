import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../integrations/supabase/client';
import { showError } from '../utils/toast';
import { PendingOrderItem } from '../types/orderTypes';

interface UseStatusOrderDataProps {
  durationFilter: string;
  searchTerm: string;
}

type FetchOverride = {
  searchTerm?: string;
  durationFilter?: string;
};

export const useStatusOrderData = ({
  durationFilter,
  searchTerm,
}: UseStatusOrderDataProps) => {
  const [data, setData] = useState<PendingOrderItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchStatusOrders = useCallback(async (override?: FetchOverride) => {
    setLoading(true);
    setError(null);
    try {
      const sTerm = override?.searchTerm ?? searchTerm;
      const dFilter = override?.durationFilter ?? durationFilter;

      let fromDays = 0, toDays = 99999;
      if (dFilter === '1-7') { fromDays = 1; toDays = 7; }
      else if (dFilter === '8-14') { fromDays = 8; toDays = 14; }
      else if (dFilter === '>14') { fromDays = 15; toDays = 99999; }

      // Query orders READY
      let query = supabase
        .from('orders')
        .select(`
          id, created_at, order_date, pickup_date, invoice_number,
          customer_id, customer_display_name, customer_display_phone,
          kasir_id, total_amount, notes, priority, payment_status, order_status,
          discount_amount, tax_amount, final_amount, payment_method, bank_name,
          ready_status,
          pelanggan:customers(nama_pelanggan, telepon),
          profiles:profiles(first_name, last_name),
          order_items:order_items(
            id, product_id, product_name, quantity, unit_price,
            discount_per_item, subtotal_per_item
          )
        `)
        .eq('ready_status', 'ready')
        .order('created_at', { ascending: false });

      // Search sederhana di nama / invoice / telepon
      if (sTerm?.trim()) {
        query = query.or([
          `customer_display_name.ilike.%${sTerm}%`,
          `invoice_number.ilike.%${sTerm}%`,
          `customer_display_phone.ilike.%${sTerm}%`
        ].join(','));
      }

      // Filter durasi tunggu berbasis hari sejak created_at
      const { data: rows, error: qErr } = await query;
      if (qErr) throw qErr;

      // Hitung durasi_tunggu client-side (biar kompatibel dengan table HistoryPending)
      const now = Date.now();
      const byDurasi = (row: any) => {
        const d = Math.floor((now - new Date(row.created_at).getTime()) / (1000 * 60 * 60 * 24));
        return (d >= fromDays && d <= toDays);
      };

      const mapped = (rows ?? [])
        .filter(byDurasi)
        .map((row: any) => ({
          ...row,
          durasi_tunggu: Math.floor((now - new Date(row.created_at).getTime()) / (1000*60*60*24)),
        })) as PendingOrderItem[];

      setData(mapped);
    } catch (e: any) {
      console.error(e);
      setError(e?.message || 'Gagal memuat Status Order.');
      showError(e?.message || 'Gagal memuat Status Order.');
    } finally {
      setLoading(false);
    }
  }, [durationFilter, searchTerm]);

  useEffect(() => { fetchStatusOrders(); }, [fetchStatusOrders]);

  return { data, loading, error, fetchStatusOrders, setData };
};
