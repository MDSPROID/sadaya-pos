import React from 'react';
import { Trash2 } from 'lucide-react';

interface AdditionalOption {
  id: string;
  name: string;
  cost: number;
  quantity: number;
  selected: boolean;
}

interface OrderItem {
  tempId: string;
  product_id: string;
  product_name: string;
  unit_price: number;
  quantity: number;
  discount_per_item: number;
  subtotal_per_item: number; /* Fixed: Changed from subtotal_per_per_item */
  dimensions: {
    panjang?: number;
    lebar?: number;
    satuan?: string;
    tebal_bahan_id?: string;
    tebal_bahan_nama?: string;
    additional_options?: AdditionalOption[]; // Nested here as per DB schema
  } | null;
  notes_per_item: string;
  designer_id: string | null;
  designer_name: string | null;
  satuan_nama: string | null;
  bahan_nama: string | null;
  mesin_nama: string | null;
}

interface DesignerOption {
  id: string;
  name: string;
}

interface OrderItemsTableProps {
  items: OrderItem[];
  designerOptions: DesignerOption[];
  onRemoveItem: (tempId: string) => void;
  onUpdateItemDesigner: (tempId: string, designerId: string, designerName: string) => void;
}

const OrderItemsTable: React.FC<OrderItemsTableProps> = ({ items, designerOptions, onRemoveItem, onUpdateItemDesigner }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6 flex-shrink-0">
      <h2 className="text-xl font-semibold text-gray-900 mb-4">Daftar Item Pesanan</h2>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">No.</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Produk</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ukuran</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Keterangan</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Desainer</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Harga</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Disc</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Qty</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subtotal</th>
              <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {items.length === 0 ? (
              <tr>
                <td colSpan={10} className="px-4 py-2 text-center text-sm text-gray-500">Belum ada item dalam pesanan.</td>
              </tr>
            ) : (
              items.map((item, index) => (
                <tr key={item.tempId}>
                  <td className="px-4 py-2 text-sm text-gray-900">{index + 1}</td>
                  <td className="px-4 py-2 text-sm font-medium text-gray-900">{item.product_name}</td>
                  <td className="px-4 py-2 text-sm text-gray-900">
                    {item.dimensions?.panjang}x{item.dimensions?.lebar} {item.dimensions?.satuan}
                    {item.dimensions?.tebal_bahan_nama && ` (${item.dimensions.tebal_bahan_nama})`}
                    {item.dimensions?.additional_options && item.dimensions.additional_options.length > 0 && (
                      <div className="text-xs text-gray-600 mt-1">
                        {item.dimensions.additional_options.map(opt => `${opt.name} (${opt.quantity})`).join(', ')}
                      </div>
                    )}
                  </td>
                  <td className="px-4 py-2 text-sm text-gray-900">{item.notes_per_item || '-'}</td>
                  <td className="px-4 py-2 text-sm text-gray-900">
                    <select
                      value={item.designer_id || ''}
                      onChange={(e) => onUpdateItemDesigner(item.tempId, e.target.value, e.target.options[e.target.selectedIndex].text)}
                      className="w-full px-2 py-1 border border-gray-300 rounded-md text-xs"
                    >
                      <option value="">Pilih Desainer</option>
                      {designerOptions.map(d => (
                        <option key={d.id} value={d.id}>{d.name}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2 text-sm text-gray-900">Rp {item.unit_price.toLocaleString('id-ID')}</td>
                  <td className="px-4 py-2 text-sm text-gray-900">Rp {item.discount_per_item.toLocaleString('id-ID')}</td>
                  <td className="px-4 py-2 text-sm text-gray-900">{item.quantity}</td>
                  <td className="px-4 py-2 text-sm text-gray-900">Rp {item.subtotal_per_item.toLocaleString('id-ID')}</td> {/* Fixed: Changed from subtotal_per_per_item */}
                  <td className="px-4 py-2 text-right">
                    <button onClick={() => onRemoveItem(item.tempId)} className="text-red-600 hover:text-red-900">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default OrderItemsTable;